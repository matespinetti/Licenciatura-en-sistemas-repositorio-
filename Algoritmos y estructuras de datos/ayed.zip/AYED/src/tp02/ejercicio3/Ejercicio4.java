package tp02.ejercicio3;

public class Ejercicio4 {
	public static void main(String[] args) {
		String s = "([mateo]"
				)";
		System.out.println(TestBalanceo.estaBalanceado(s));
	}
}

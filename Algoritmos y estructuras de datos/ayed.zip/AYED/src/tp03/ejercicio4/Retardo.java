



package tp03.ejercicio4;

public class Retardo {
	private int retardoIzq;
	private int retardoDer;
	public Retardo(int retardoIzq, int retardoDer) {
		super();
		this.retardoIzq = retardoIzq;
		this.retardoDer = retardoDer;
	}
	public int getRetardoIzq() {
		return retardoIzq;
	}
	public void setRetardoIzq(int retardoIzq) {
		this.retardoIzq = retardoIzq;
	}
	public int getRetardoDer() {
		return retardoDer;
	}
	public void setRetardoDer(int retardoDer) {
		this.retardoDer = retardoDer;
	}
	
	
	
	
}
